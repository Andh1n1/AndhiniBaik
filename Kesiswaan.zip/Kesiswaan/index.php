<?php
session_start();

if(!isset($_SESSION['id'])){
    header("location:login.php");
}
?>

<!DOCTYPE html>
<html>

<head>
  <!-- Basic -->
  <meta charset="utf-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <!-- Mobile Metas -->
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
  <!-- Site Metas -->
  <meta name="keywords" content="" />
  <meta name="description" content="" />
  <meta name="author" content="" />
  <link rel="shortcut icon" href="images/logosmk.ico" type="">

  <title> Kesiswaan-SMKN2BE </title>

  <!-- bootstrap core css -->
  <link rel="stylesheet" type="text/css" href="css/bootstrap.css" />

  <!--owl slider stylesheet -->
  <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css" />
  <!-- nice select  -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jquery-nice-select/1.1.0/css/nice-select.min.css" integrity="sha512-CruCP+TD3yXzlvvijET8wV5WxxEh5H8P4cmz0RFbKK6FlZ2sYl3AEsKlLPHbniXKSrDdFewhbmBK5skbdsASbQ==" crossorigin="anonymous" />
  <!-- font awesome style -->
  <link href="css/font-awesome.min.css" rel="stylesheet" />

  <!-- Custom styles for this template -->
  <link href="css/style.css" rel="stylesheet" />
  <!-- responsive style -->
  <link href="css/responsive.css" rel="stylesheet" />

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

<link rel="icon" href="/Kesiswaan/images/logo.png" type="image/png">
</head>

<body>

  <div class="hero_area">
    <div class="bg-box">
      <img src="images/bg1.jpg" alt="kesiswaan">
    </div>
    <!-- header section strats -->
    <header class="header_section">
      <div class="container">
        <nav class="navbar navbar-expand-lg custom_nav-container ">
          <a class="navbar-brand" href="index.html">
            <span>
              Kesiswaan SMKN 2 Baleendah
            </span>
          </a>

          <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class=""> </span>
          </button>

          <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav  mx-auto ">
              <li class="nav-item active">
                <a class="nav-link" href="index.html">Home <span class="sr-only">(current)</span></a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="members.html">Members</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="about.html">Program Kerja</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="pengurus.php">Biodata</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="logout.php">Logout</a>
              </li>
            </ul>
            <div class="user_option">
              
              <a class="cart_link" href="#"></a>
              <form class="form-inline">
                
              </form>
            </div>
          </div>
        </nav>
      </div>
    </header>
    <!-- end header section -->
    
    <!-- slider section -->
    <section class="slider_section ">
      <div id="customCarousel1" class="carousel slide" data-ride="carousel">
        <div class="carousel-inner">
          <div class="carousel-item active">
            <div class="container ">
              <div class="row">
                <div class="col-md-7 col-lg-6 ">
                  <div class="detail-box">
                    <h1>
                      Visi
                    </h1>
                    <p>
                      Mewujudkan peserta didik yang berkarakter, disiplin, berprestasi, dan aktif dalam kegiatan sekolah serta mampu bersaing secara positif.
                    </p>
                    
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="carousel-item ">
            <div class="container ">
              <div class="row">
                <div class="col-md-7 col-lg-6 ">
                  <div class="detail-box">
                    <h1>
                      Misi
                    </h1>
                    <p>
                      Mengembangkan karakter, kedisiplinan, dan potensi siswa melalui kegiatan kesiswaan yang positif, terarah dan berkelanjutan.
                    </p>
                    
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="carousel-item">
            <div class="container ">
              <div class="row">
                <div class="col-md-7 col-lg-6 ">
                  <div class="detail-box">
                    <h1>
                      Tujuan
                    </h1>
                    <p>
                      Mengembangkan potensi siswa sesuai tujuan pendidikan nasional melalui pembinaan karakter, lingkungan sekolah yang kondusif, sikap berbangsa, apresiasi seni, serta keseimbangan jasmani dan rohani.
                    </p>
                    
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="container">
          <ol class="carousel-indicators">
            <li data-target="#customCarousel1" data-slide-to="0" class="active"></li>
            <li data-target="#customCarousel1" data-slide-to="1"></li>
            <li data-target="#customCarousel1" data-slide-to="2"></li>
          </ol>
        </div>
      </div>

    </section>
    <!-- end slider section -->

    <?php echo $_SESSION['username']; ?>
    <h3>Halo, <?php echo $_SESSION['username']; ?></h3>
  </div>
<section class="offer_section layout_padding-bottom"></section>
<div class="container">
      <div class="heading_container heading_center">
        <h2>
          Ketua dan Wakil
        </h2>
      </div>
  <section class="offer_section layout_padding-bottom">
    <div class="offer_container">
      <div class="container ">
        <div class="row">
          <div class="col-md-6  ">
            <div class="box ">
              <div class="img-box">
                <img src="images/p-tatang.jpeg" alt="">
              </div>
              <div class="detail-box">
                <h6>
                  <span>Pak Tatang</span>
                </h6>
                <p>Memimpin dan bertanggung jawab atas penyelenggaraan pendidikan di sekolah</p>
              </div>
            </div>
          </div>
          <div class="col-md-6  ">
            <div class="box ">
              <div class="img-box">
                <img src="images/pak-dede.jpeg" alt="">
              </div>
               <div class="detail-box">
                 <h6>
                  <span>Pak Dede Riyadi</span>
                </h6>
                <p>Sebagai pemimpin utama dalam mengoordinasikan kegiatan dan organisasi siswa</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- offer section -->

  <!-- end offer section -->

  <!-- food section -->

  <section class="food_section layout_padding-bottom">
    <div class="container">
      <div class="heading_container heading_center">
        <h2>
          Anggota & Dokumentasi
        </h2>
      </div>

      <ul class="filters_menu">
        <li class="active"  data-filter=".pizza">Staff dan Pembina OSIS</li>
        <li data-filter=".burger">Kegiatan Positif</li>
      </ul>

      <div class="filters-content">
        <div class="row grid">
          <div class="col-sm-6 col-lg-4 all pizza">
            <div class="box">
              <div>
                <div class="img-box">
                  <img src="images/p-odih.jpeg" alt="">
                </div>
                <div class="detail-box">
                  <h5>
                    Pak Odih
                  </h5>
                  <p>
Bertanggung jawab dalam membina, mengawasi, dan menegakkan tata tertib kedisiplinan siswa putra guna menciptakan lingkungan sekolah yang tertib, aman, dan kondusif.                  </p>
                </div>
              </div>
            </div>
          </div>
          <div class="col-sm-6 col-lg-4 all pizza">
            <div class="box">
              <div>
                <div class="img-box">
                  <img src="images/p-dodi.jpeg" alt="">
                </div>
                <div class="detail-box">
                  <h5>
                    Pak Dodi Sugiri
                  </h5>
                  <p>
                    Membimbing, mengarahkan, dan mendampingi kegiatan OSIS dalam perencanaan serta pelaksanaan program kerja guna menumbuhkan jiwa kepemimpinan dan tanggung jawab siswa.
                  </p>
                  
                </div>
              </div>
            </div>
          </div>
          <div class="col-sm-6 col-lg-4 all pizza">
            <div class="box">
              <div>
                <div class="img-box">
                  <img src="images/foto.jpg" alt="">
                </div>
                <div class="detail-box">
                  <h5>
                    Bu Fitri
                  </h5>
                  <p>
Berperan dalam pembinaan dan pengawasan kedisiplinan siswa putri serta membentuk sikap disiplin, sopan, dan berkarakter sesuai dengan nilai dan aturan sekolah.
                  </p>
                  
                </div>
              </div>
            </div>
          </div>
          <div class="col-sm-6 col-lg-4 all burger">
            <div class="box">
              <div>
                <div class="img-box">
                  <img src="images/murajaah.jpeg" alt="">
                </div>
                <div class="detail-box">
                  <h5>
                    Muraja'ah (Selasa & Kamis)
                  </h5>
                  <p>
Kegiatan pembiasaan untuk tadarus Al-Qur’an sebagai upaya menumbuhkan karakter religius dan meningkatkan kedisiplinan spiritual siswa.                  </p>
                </div>
              </div>
            </div>
          </div>

          <div class="col-sm-6 col-lg-4 all burger">
            <div class="box">
              <div>
                <div class="img-box">
                  <img src="images/upaacara.jpeg" alt="">
                </div>
                <div class="detail-box">
                  <h5>
                    Upacara (Senin)
                  </h5>
                  <p>
                    Kegiatan rutin untuk menanamkan nilai kedisiplinan, tanggung jawab, serta rasa cinta tanah air dan semangat kebangsaan kepada siswa.
                  </p>
                </div>
              </div>
            </div>
          </div>
          
          <div class="col-sm-6 col-lg-4 all burger">
            <div class="box">
              <div>
                <div class="img-box">
                  <img src="images/literasi.jpeg" alt="">
                </div>
                <div class="detail-box">
                  <h5>
                    Literasi (Rabu)
                  </h5>
                  <p>
                    Kegiatan pembiasaan membaca untuk meningkatkan minat baca, wawasan, serta kemampuan berpikir kritis dan kreatif siswa
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="btn-box">
        <a href="">
          Kembali Keatas
        </a>
      </div>
    </div>
  </section>

  <!-- end food section -->

  <!-- about section -->

  <section class="about_section layout_padding">
    <div class="container  ">

      <div class="row">
        <div class="col-md-6 ">
          <div class="img-box">
            <img src="images/dok1.jpeg" alt="">
          </div>
        </div>
        <div class="col-md-6">
          <div class="detail-box">
            <div class="heading_container">
              <h2>
                Fungsi adanya kesiswaan
              </h2>
            </div>
            <p>
              Bidang kesiswaan berfungsi sebagai sarana pembinaan peserta didik dalam mengembangkan sikap
              disiplin,tanggung jawab, dan kepemimpinan sekaligus menjadi wadah penyaluran minat dan bakat siswa
              melalui kegiatan yang terencana, edukatif, dan membangun karakter positif di lingkungan sekolah.
            </p>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- end about section -->

  

  <!-- client section -->

  <section class="offer_section layout_padding-bottom">
  </section>

  <section class="client_section layout_padding-bottom">
    <div class="container">
      <div class="heading_container heading_center psudo_white_primary mb_45">
        <h2>
          Program Kesiswaan 
        </h2>
      </div>
      <div class="carousel-wrap row ">
        <div class="owl-carousel client_owl-carousel">
          <div class="item">
            <div class="box">
              <div class="detail-box">
                <h6>
                  1. Waluya Raga (Kesehatan Jasmani)
                </h6>
                <p>
                  Program kerja Waluya Raga berfokus pada pembinaan kesehatan dan kebugaran jasmani siswa melalui penanaman kedisiplinan,
                   pembiasaan hidup sehat seperti kegiatan Senam Kesegaran Jasmani (SKJ) setiap hari Jumat, serta pelaksanaan ekstrakurikuler 
                   olahraga dan kegiatan pendukung seperti Perisai Diri dan PMR untuk meningkatkan kesehatan fisik dan mental siswa.
              </div>
            </div>
          </div>
          <div class="item">
            <div class="box">
              <div class="detail-box">
                <h6>
                  2. Waluya Rasa (Kesehatan Rohani dan Apresiasi Seni)
                </h6>
                <p>
                  Program Waluya Rasa bertujuan menumbuhkan kepekaan emosional, spiritual, dan apresiasi seni siswa melalui pembiasaan positif 
                  seperti Duha Bersama dan Tadarus Pagi, serta kegiatan ekstrakurikuler kesenian untuk membentuk kehalusan budi pekerti.
                </p>
              </div>
            </div>
          </div>
          <div class="item">
            <div class="box">
              <div class="detail-box">
                <h6>
                  3. Waluya Karsa (Kemauan dan Keterampilan)
                </h6>
                <p>
                  Program Waluya Karsa menitikberatkan pada pengembangan inisiatif, kepemimpinan, dan keterampilan siswa melalui latihan kepemimpinan, 
                  keaktifan dalam organisasi OSIS, serta berbagai ekstrakurikuler inovasi dan bahasa guna meningkatkan kemandirian dan kemampuan komunikasi.
                </p>
              </div>
            </div>
          </div>
          <div class="item">
            <div class="box">
              <div class="detail-box">
                <h6>
                  4. Waluya Cipta (Kecerdasan Intelektual)
                </h6>
                <p>
                Program Waluya Cipta berfokus pada pengembangan daya pikir dan intelektual siswa melalui kegiatan literasi, pembinaan wali kelas, serta ekstrakurikuler 
                ilmiah seperti KKIR guna meningkatkan wawasan dan kemampuan akademik siswa.
                </p>
              </div>
            </div>
          </div>
          <div class="item">
            <div class="box">
              <div class="detail-box">
                <h6>
                  5. Waluya Batin (Pembentukan Karakter dan Moral)
                </h6>
                <p>
                  Program Waluya Batin menjadi landasan pembentukan kepribadian, kedisiplinan, dan moral siswa melalui pembinaan kedisiplinan, pelaksanaan upacara bendera, 
                  penguatan wawasan kebangsaan melalui Pramuka dan Paskibra, serta kegiatan kebersihan lingkungan.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>

  
  

  <!-- end client section -->

  <!-- footer section -->
  <footer class="footer_section">
    <div class="container">
      <div class="row">
        <div class="col-md-4 footer-col">
          <div class="footer_contact">
            <h4>
              Contact Us
            </h4>
            <div class="contact_link_box">
              <a href="https://www.google.com/maps/place/SMKN+2+Baleendah/@-7.0018153,107.6243747,17z/data=!3m1!4b1!4m6!3m5!1s0x2e68e65c6d29f64b:0x77201ce39e73f764!8m2!3d-7.0018153!4d107.6243747!16s%2Fg%2F1pzr9pm1f?entry=ttu&g_ep=EgoyMDI1MTExNi4wIKXMDSoASAFQAw%3D%3D" target="_blank">
                <i class="fa fa-map-marker" aria-hidden="true"></i>
                <span>
                  Smkn 2 Baleendah
                </span>
              </a>
              <a href="https://api.whatsapp.com/send?phone=+6282117945885&text=Nomor Pak Dede Riyadi, mohon chat yang sopan ya">
                <i class="fa fa-phone" aria-hidden="true"></i>
                <span>
                  Call +6282117945885
                </span>
              </a>
              <a href="https://www.instagram.com/smkn2be" class="ig-link" target="_blank">
              <i class="fab fa-instagram"></i> Instagram SMKN 2 Baleendah
              </a>
            </div>
          </div>
        </div>
        <div class="col-md-4 footer-col">
          <div class="footer_detail">
            <a href="" class="footer-logo">
              Kesiswaan
            </a>
            <p>
              Kesiswaan menyediakan layanan dan informasi. Kami hadir untuk membantu setiap siswa berkembang melalui kegiatan dan pendampingan positif
            </p>
          </div>
        </div>
        <div class="col-md-4 footer-col">
          <h4>
            Available
          </h4>
          <p>
            Senin-Juma't
          </p>
          <p>
            07.00 Am - 18.00 Pm
          </p>
        </div>
      </div>
      <div class="footer-info">
        <p>
          &copy; <span id="displayYear"></span> All Rights Reserved By
          <a href="https://html.design/">Andhini Putri Wijaya</a><br><br>
        </p>
      </div>
    </div>
  </footer>
  <!-- footer section -->

  <!-- jQery -->
  <script src="js/jquery-3.4.1.min.js"></script>
  <!-- popper js -->
  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous">
  </script>
  <!-- bootstrap js -->
  <script src="js/bootstrap.js"></script>
  <!-- owl slider -->
  <script src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js">
  </script>
  <!-- isotope js -->
  <script src="https://unpkg.com/isotope-layout@3.0.4/dist/isotope.pkgd.min.js"></script>
  <!-- nice select -->
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-nice-select/1.1.0/js/jquery.nice-select.min.js"></script>
  <!-- custom js -->
  <script src="js/custom.js"></script>
  <!-- Google Map -->
  <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCh39n5U-4IoWpsVGUHWdqB6puEkhRLdmI&callback=myMap">
  </script>
  <!-- End Google Map -->

</body>

</html>